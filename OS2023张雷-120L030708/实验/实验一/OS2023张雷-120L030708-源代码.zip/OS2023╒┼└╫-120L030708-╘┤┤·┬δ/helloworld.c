#include <stdio.h>
#include "syscall.h"

void test(const char* name,char* name_buf,int name_buf_size){
    int name_size=strlen(name)+1;
    int copied_size=0;
    if((copied_size=iam(name))!=name_size){
        printf("iam() error");
        return;
    }
    if((copied_size=whoami(name_buf,name_buf_size))==-1){
        printf("whoami() error");
        return;
    }
    printf("%s\n",name_buf);
}

int main(int argc,char** argv){
    const int name_buf_size=50;
    char name_buf[name_buf_size];
    
    test("zhanglei-120L030708",name_buf,name_buf_size);
    test("23453864182", name_buf,name_buf_size);
    test("235687359969923659",name_buf,name_buf_size);
}